#mypackage
this library you was created as an example of how to use recursion and sorting methods.there are two file in the package name named recursion.py and sorting.py. inside recursion.py there is four functions which is sum_array,fibonacci,factorial and reverse. inside sorting.py there is double_sort,merge_sort and quick_sort functions

##building this package locally
'python setup.py sdist'

##installing this package  from GitHub
'pip install git+http://github.com/Phomolo/example-python-package1.git'
##updating this package from github
'pip install --upgrade git+http://github/Phomolo/example-python-package1.git'
